/**
 * Partida de dardos entre 2 jugadores
 */
public class Partida
{
    //A CONSTRUIR
}
