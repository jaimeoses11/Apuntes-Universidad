/**
 * Representa a un jugador del juego de dardos.
 */
public class Jugador
{
    // Atributo: la puntuación del jugador
    private int puntuacion;

    /**
     * Constructor: Asigna al atributo del jugador la puntuación objetivo de la partida
     */
    //A CONSTRUIR

    
    /**
     * Averigua si el jugador ha alcanzado la puntuacion que permite ganar la partida 
     */
    //A CONSTRUIR

    
    /**
     * Calcula el numero de puntos que ha obtenido el jugador en una tirada.
     * En una tirada se hacen 3 lanzamientos, salvo si ya se ha ganado con el 1º o 2º
     * lanzamientos.
     * Si en la tirada el jugador obtiene un numero de puntos mayor que su puntuacion, la
     * tirada se anula (obtiene 0 puntos)
     */
    //A CONSTRUIR

    
    /**
     * Actualiza la puntuacion del jugador tras haber realizado una tirada
     */
    //A CONSTRUIR


    /**
     * Muestra al usuario la puntuacion del jugador
     */
    //A CONSTRUIR

}