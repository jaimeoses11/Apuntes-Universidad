
/**
 * Write a description of class Buscaminas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Buscaminas {
    
    /**
     * Method main. Realiza una ejecución típica del juego 
     * del buscaminas. Dicha ejecución solicitará al usuario
     * valores de dimensiones del tablero y el número de minas
     * para iniciar el juego y, cuando sean válidos, realizará
     * el diálogo necesario con el usuario para el desarrollo 
     * del juego hasta su finalización.
     * Se considerarán válidos los valores si filas y columnas
     * son positivos y el número de minas no supera la mitad
     * de las casillas del tablero.
     */
    public static void main (String [] argumentos){
        
        // DESARROLLAR
        
    }
}
