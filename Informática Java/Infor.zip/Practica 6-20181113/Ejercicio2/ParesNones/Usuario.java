
/**
 * Write a description of class Usuario here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Usuario
{
    
  

    /**
     * Constructor for objects of class Usuario
     */
    public Usuario()
    {
       
    }

   
}
