
/**
 * Write a description of class Ejercicio1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ejercicio1
{
    public static void main(String [] args){
        double d;
        double D;
        
        
        do{
            d= Teclado.leerReal("Dividendo ");
        } while(d<0);
        do{
            D= Teclado.leerReal("Divisor: ");
        } while(D<0);
        double c=d/D;
        double r=d%D;
        System.out.println("Cociente: "+c+"Resto: "+r);
        
        
    }
}
