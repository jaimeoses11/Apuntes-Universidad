import java.util.*;
/**
 * Write a description of class Ejercicio10 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ejercicio10
{
    public static void main(String [] args){
     char c;
     int contador=0;
     boolean anterior;
     System.out.println("Introduce secuencia de mayusculas acabada en '.'");
     Scanner teclado=new Scanner(System.in);
     teclado.useDelimiter("");
     c=teclado.next().charAt(0);
     while(c!='.'){
         anterior=c=='E';
         c=teclado.next().charAt(0);
         if(anterior&&(c=='L'))
             contador+=1;
        }
        System.out.println("Numero de veces que aparece 'EL' "+contador);
    }
    
    
}
                        
                     
  


